import os
from Facebook.utils.Function import check_token

def add_token(token_name, token):
    try:
        with open(f"Facebook/Tokens/{token_name}.txt", "w") as f:
            f.write(token)

        return True
    except:
        return False

def token_list():
    tokens = os.listdir("Facebook/Tokens/")
    token_dict = {}
    number_list = []
    num = 0

    for token in tokens:
        num += 1
        token_dict[str(num)] = token
        number_list.append(str(num))

    return token_dict, number_list

