import os
from colorama import Fore, Back, Style, init
init(autoreset=True)

# Colors
red = Fore.RED + Style.BRIGHT
yellow = Fore.YELLOW + Style.BRIGHT
cyan = Fore.CYAN + Style.BRIGHT
magenta = Fore.MAGENTA + Style.BRIGHT
blue = Fore.BLUE + Style.BRIGHT
green = Fore.GREEN + Style.BRIGHT
white = Fore.WHITE + Style.BRIGHT

colors = [red, yellow, cyan, magenta, blue, green, white]


def entry(type):

    if type == "option":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Number:- " + green))
        return user

    elif type == "token_name":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Token File Name:- " + green))
        return user

    elif type == "token":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Token:- " + green))
        return user

    elif type == "delay":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Delay Time (in minutes):- " + green))
        return user

    elif type == "comment":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Comment:- " + green))
        return user

    elif type == "link":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Link:- " + green))
        return user

    elif type == "comment_num":
        user = input(str("\n" + cyan + "[ " + yellow + "➧" + cyan + " ]" + magenta + " Enter Number Of Comments:- " + green))
        return user

def banner():
    banner_1 = open("banner/banner_1.txt").readlines()
    banner_2 = open("banner/banner_2.txt").readlines()
    for lines in banner_1:
        print (colors[3]+lines, end="")
    for lines in banner_2:
        print (colors[2]+lines, end="")


def check_token():
    tokens = os.listdir("Facebook/Tokens/")
    if tokens == []:
        return False
    else:
        return True

def box(number):
        number = cyan + "[ " + white + str(number) + cyan + " ] "
        return number

def token_name(file_name):
    files = os.listdir("Facebook/Tokens/")
    if f"{file_name}.txt" in files:
        return False
    else:
        return True

def token_text(token):
    exists = True
    files = os.listdir("Facebook/Tokens/")
    for file in files:
        read = open(f"Facebook/Tokens/{file}").read()
        if token == read:
            exists = False
            break

    return exists


def check_list(list_1, list_2): 
    same = True
    for i in list_1:
        if i not in list_2:
            same = False
            break
    return same
