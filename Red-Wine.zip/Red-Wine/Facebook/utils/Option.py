import time
from Facebook.utils.Function import box
from colorama import Fore, Back, Style, init
init(autoreset=True)

# Colors
red = Fore.RED + Style.BRIGHT
yellow = Fore.YELLOW + Style.BRIGHT
cyan = Fore.CYAN + Style.BRIGHT
magenta = Fore.MAGENTA + Style.BRIGHT
blue = Fore.BLUE + Style.BRIGHT
green = Fore.GREEN + Style.BRIGHT
white = Fore.WHITE + Style.BRIGHT

colors = [red, yellow, cyan, magenta, blue, green, white]

class options:

    def menu_1():
        print ("\n\n" + cyan + "[ " + white + "OPTIONS" + cyan + " ]")
        time.sleep(0.03)
        print ("\n" + box(1) + yellow + "POST COMMENT")
        time.sleep(0.03)
        print (box(2) + yellow + "TOKEN SETTING")
        time.sleep(0.03)
        print (box(3) + yellow + "CONTACT")
        time.sleep(0.03)
        print (box(4) + yellow + "EXIT")

    def menu_2():
        print ("\n\n" + cyan + "[ " + white + "OPTIONS" + cyan + " ]")
        time.sleep(0.03)
        print ("\n" + box(1) + yellow + "SINGLE ACCOUNT")
        time.sleep(0.03)
        print (box(2) + yellow + "MULTIPLE ACCOUNTS")
        time.sleep(0.03)
        print (box(3) + yellow + "BACK")

    def menu_3():
        print ("\n\n" + cyan + "[ " + white + "OPTIONS" + cyan + " ]")
        time.sleep(0.03)
        print ("\n" + box(1) + yellow + "VIEW TOKEN")
        time.sleep(0.03)
        print (box(2) + yellow + "ADD TOKEN")
        time.sleep(0.03)
        print (box(3) + yellow + "DELETE TOKEN")
        time.sleep(0.03)
        print (box(4) + yellow + "BACK")


