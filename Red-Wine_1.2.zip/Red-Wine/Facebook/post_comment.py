import os
import time
from datetime import datetime
import facebook
import requests
from bs4 import BeautifulSoup
from Facebook.utils.Function import entry, banner
from colorama import Fore, Back, Style, init
init(autoreset=True)

yellow = Fore.YELLOW + Style.BRIGHT

def write_com():
    msg_list = []
    os.system("clear")
    banner()
    print (yellow + "\n\nEnter Path to the File which contains comments list")
    user = entry("comment_path")
    msg_list = open(user).read().split("\n")
    for empty in msg_list:
        if empty == "":
            msg_list.remove("")
    return msg_list

def get_id(link):
    line = link.replace("/", " ")
    line = line.replace("=", " ")
    line = line.replace("&", " ")
    line = line.replace("?", " ").split()
    if line[1] == "fb.watch":
        result = requests.get(link).content
        result = BeautifulSoup(result, "html5lib").prettify().split()
        line = result[19].replace("/", " ").split()
        id = line[-2]
        return id

    elif 'facebook.com' in line[1]:
        if "story.php?story_fbid" in line:
            id_1 = line[line.index("story.php?story_fbid")+1]
            id_2 = line[line.index("id")+1]
            id = f"{id_2}_{id_1}"
            return id

        else:
            for id in line:
                try:
                    id = int(id)
                    id = str(id)
                    break
                except:
                    pass

            return id


def comment(token, id, message):
    try:
        fb = facebook.GraphAPI(token)
        fb.put_object(id, "comments", message=message)
        setup = datetime.now()
        clock = setup.strftime('%Y/%m/%d %I:%M:%S').split()
        clock = str(clock[1])
        return True, clock
    except Exception as error:
        setup = datetime.now()
        clock = setup.strftime('%Y/%m/%d %I:%M:%S').split()
        clock = str(clock[1])
        return False, clock, error

