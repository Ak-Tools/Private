import os
import time

def main():
    modules = ["requests", "bs4", "html5lib", "colorama", "facebook-sdk", "mechanize"]
    os.system("clear")
    print ("\n\nINSTALLING REQUIREMENTS\n")
    os.system("pkg update -y && pkg upgrade -y")
    for module in modules:
        os.system(f"pip install {module}")

    os.system("clear")
    print ("SETUP COMPLETE")

main()
