import os
import time
import requests
from Facebook.token_manager import add_token, token_list
from Facebook.utils.Option import options
from Facebook.post_comment import get_id, write_com, comment
from Facebook.utils.Function import banner, entry, check_token, box, token_name, token_text, check_list

from colorama import Fore, Back, Style, init
init(autoreset=True)

# Colors
red = Fore.RED + Style.BRIGHT
yellow = Fore.YELLOW + Style.BRIGHT
cyan = Fore.CYAN + Style.BRIGHT
magenta = Fore.MAGENTA + Style.BRIGHT
blue = Fore.BLUE + Style.BRIGHT
green = Fore.GREEN + Style.BRIGHT
white = Fore.WHITE + Style.BRIGHT

colors = [red, yellow, cyan, magenta, blue, green, white]

def validate(menu, option):
    if menu == "1":
        if option == "1":
            os.system("clear")
            banner()
            options.menu_2()
            user = entry("option")
            validate("2", user)

        elif option == "2":
            os.system("clear")
            banner()
            options.menu_3()
            user = entry("option")
            validate("3", user)

        elif option == "3":
            print (magenta + "This function will be added in the next update")
            time.sleep(0.7)

        elif option == "4":
            print (magenta + "This function will be added in the next update")
            time.sleep(0.7)

        elif option == "5":
            version = open(".version").read().strip()
            os.system("clear")
            banner()
            print (yellow + "\n\nChecking for update")
            check = requests.get("https://raw.githubusercontent.com/Ak-Tools/Private/main/Red-Wine-Updates.txt").content.decode('utf-8').strip()
            if check == version:
                print (green + "\nTool is fully Updated!")
                user = input(blue + "\n\nPress Enter To Continue:")

            else:
                print (magenta + "\nUpdate Found!")
                print (magenta + "Did you want to update? (Y/N)")
                ask = input(cyan + "\nEnter Choice:- ")
                if ask.lower() == "y" or ask.lower() == "yes":
                    os.system("clear")
                    banner()
                    print (blue + "Downloading Update")
                    os.system(f"wget https://github.com/Ak-Tools/Private/raw/main/Red-Wine_{check}.zip -q && mv Red-Wine_{check}.zip .update/")
                    print (blue + "Extracting Files")
                    os.system(f"unzip .update/Red-Wine_{check}.zip > /dev/null")
                    print (blue + "Saving Tokens")
                    os.system("cp Facebook/Tokens/* .update/Red-Wine/Facebook/Tokens/")
                    print (blue + "Removing old files")
                    os.system("mv .update/Red-Wine $HOME/.Red-Wine")
                    os.system("rm -rf $HOME/Red-Wine")
                    os.system("mv $HOME/.Red-Wine $HOME/Red-Wine")
                    os.chdir("/data/data/com.termux/files/home/Red-Wine")
                    print (green + "\nUpdate Complete!")
                    user = input(blue + "Press Enter To Continue:")
                    exit()

        elif option == "6":
            os.system("clear")
            banner()
            print (yellow + "\n\nTELEGRAM USERNAME:- " + green + "@AnOnYmOuS_WaR")
            ask = input(blue + "\n\nPress Enter To Continue:")

        else:
            print (red + "Invalid Choice!")
            time.sleep(0.7)

    elif menu == "2":
        if option == "1":
            if check_token():
                token_dict = token_list()[0]
                number_list = token_list()[1]
                os.system("clear")
                banner()
                print (yellow + "\n\nChoose account\n")
                for token in token_dict:
                    print (box(token), yellow + token_dict[token])

                user = entry("option")
                if user in number_list:
                    token = open(f"Facebook/Tokens/{token_dict[user]}").read()
                    os.system("clear")
                    banner()
                    print (yellow + "\n\nEnter Delay time")
                    print (yellow + "Ex:- 1 = 1 minute\n")
                    delay = entry("delay")
                    delay_sec = int(delay)*60
                    os.system("clear")
                    banner()
                    print (yellow + "\n\nEnter Post link below")
                    print (yellow + "Ex:-  https://fb.watch/nxjdjdj/\n")
                    link = entry("link")
                    os.system("clear")
                    banner()
                    print (yellow + "Enter Number of times you want to send comment")
                    print (yellow + "0 = Unlimited times\n")
                    number = entry("option")
                    if number == "0":
                        number = "9"*100
                    message = write_com()
                    leng = len(message)-1
                    sub = 0
                    os.system("clear")
                    banner()
                    id = get_id(link)
                    print (yellow + "\n\nAccount:- " + green + token_dict[user])
                    print (yellow + "Delay Time:- " + green + delay + " minutes")
                    print (yellow + "Post Link:- " + green + link)
                    print (yellow + "Post Id:- " + green + id)
                    print (yellow + "Repeat Time:- " + green + number)
                    print (yellow + "Comment:- " + green + f"{message}")
                    ask = input(blue + "\nPress Enter To Continue:")
                    os.system("clear")
                    banner()
                    for repeat in range(int(number)):
                        if leng<sub:
                            sub = 0
                        status = comment(token, id, message[sub])
                        sub += 1
                        if status[0] == True:
                            print (green + f"\nComment Send [Time:- {status[1]}]")

                        else:
                            print (red + f"\nFailed To Send Comment ({token_dict[user]})")
                            with open(f"logs/{token_dict[user]}_logs.log", "a") as wri:
                                wri.write(f"[{status[1]}] {status[2]}\n")

                        print (yellow + f"\nSLEEPING {delay} minutes")
                        time.sleep(int(delay_sec))
                else:
                    print (red + "Invalid Choice!")
                    time.sleep(0.7)

            else:
                print (red + "No Token Found")
                time.sleep(0.7)

        elif option == "2":
            if check_token():
                all = False
                tokens = []
                token_dict = token_list()[0]
                number_list = token_list()[1]
                os.system("clear")
                banner()
                print (yellow + "\n\nChoose account")
                print (yellow + "Ex:- 1, 2, 3 (0 for all accounts)\n")
                for token in token_dict:
                    print (box(token), yellow + token_dict[token])

                user = entry("option")
                if user == "0":
                    for num in number_list:
                        tokens.append(token_dict[num])
                    all = True
                else:
                    user = user.replace(",", " ").split()
                if check_list(user, number_list) or all:
                    if all != True:
                        for token in user:
                            tokens.append(token_dict[token])
                    os.system("clear")
                    banner()
                    print (yellow + "\n\nEnter Delay time")
                    print (yellow + "Ex:- 1 = 1 minute\n")
                    delay = entry("delay")
                    delay_sec = int(delay)*60
                    os.system("clear")
                    banner()
                    print (yellow + "\n\nEnter Post link below")
                    print (yellow + "Ex:-  https://fb.watch/nxjdjdj/\n")
                    link = entry("link")
                    os.system("clear")
                    banner()
                    print (yellow + "Enter Number of times you want to send comment")
                    print (yellow + "0 = Unlimited times\n")
                    number = entry("option")
                    if number == "0":
                        number = "9"*100

                    os.system("clear")
                    banner()
                    print (yellow + "\n\nEnter Comment message below")
                    print (yellow + "Type 'EXIT' to save comment\n")
                    message = write_com()
                    leng = len(message)-1
                    sub = 0
                    os.system("clear")
                    banner()
                    id = get_id(link)
                    print (yellow + "\n\nAccount:- " + green + f"{tokens}")
                    print (yellow + "Delay Time:- " + green + delay + " minutes")
                    print (yellow + "Post Link:- " + green + link)
                    print (yellow + "Post Id:- " + green + id)
                    print (yellow + "Repeat Time:- " + green + number)
                    print (yellow + "Comment:- " + green + f"{message}")
                    ask = input(blue + "\nPress Enter To Continue:")
                    os.system("clear")
                    banner()
                    for repeat in range(int(number)):
                        for token in tokens:
                            if leng<sub:
                                sub = 0
                            status = comment(open(f"Facebook/Tokens/{token}").read(), id, message[sub])
                            sub += 1
                            if status[0] == True:
                                print (green + f"\nComment Send ({token}) [Time:- {status[1]}]")

                            else:
                                print (red + f"\nFailed To Send Comment ({token})")
                                with open(f"logs/{token}_logs.log", "a") as wri:
                                    wri.write(f"[{status[1]}] {status[2]}\n")

                            print (yellow + f"\nSLEEPING {delay} minutes")
                            time.sleep(int(delay_sec))
                else:
                    print (red + "Invalid Choice!")
                    time.sleep(0.7)
            else:
                print (red + "No token found")
                time.sleep(0.7)

        elif option == "3":
            pass

        else:
            print (red + "Invalid Choice!")

    elif menu == "3":
        if option == "1":
            token_dict = token_list()[0]
            number_list = token_list()[1]
            os.system("clear")
            banner()
            if check_token():
                print ("\n\n" + cyan + "[ " + white + "OPTIONS" + cyan + " ]" + "\n")
                for i in token_dict:
                    print (box(i), yellow + token_dict[i])
                user = entry("option")
                if user in number_list:
                    read = open(f"Facebook/Tokens/{token_dict[user]}").read()
                    os.system("clear")
                    banner()
                    print ("\n\n" + read)
                    ask = input(blue + "\nPress Enter To Continue:")
                else:
                    print (red + "Invalid choice!")
                    time.sleep(0.7)
            else:
                print (red + "\n\n\nNo token found")
                time.sleep(0.7)

        elif option == "2":
            os.system("clear")
            banner()
            print (yellow + "\n\nEnter file name below to save token in it")
            file_name = entry("token_name")
            if token_name(file_name):
                os.system("clear")
                banner()
                print (yellow + "\n\nEnter Token Below")
                token = entry("token")
                if token_text(token):
                    add_token(file_name, token)
                    print (green + "\nToken Created!")
                    time.sleep(0.7)
                else:
                    print (red + "\nToken Exists!")
                    time.sleep(0.7)
            else:
                print (red + "\nToken Exists!")
                time.sleep(0.7)

        elif option == "3":
            token_dict = token_list()[0]
            number_list = token_list()[1]
            os.system("clear")
            banner()
            if check_token():
                print (cyan + "\n\n[ " + white + "OPTIONS" + cyan + " ]\n")
                for token in token_dict:
                    print (box(token), yellow + token_dict[token])

                user = entry("option")
                if user not in number_list:
                    print  (red + "Invalid Choice!")
                    time.sleep(0.7)

                else:
                    os.system(f"rm Facebook/Tokens/{token_dict[user]}")
                    print (green + "\nToken Deleted")
                    time.sleep(0.7)
            else:
                print (red + "\n\n\nNo token found")
                time.sleep(0.7)

        elif option == "4":
            pass

        else:
            print (red + "Invalid Choice!")





