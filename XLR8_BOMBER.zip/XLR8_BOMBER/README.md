<h1 align="center">XLR8 BOMBER 3.0
<img src="logo.jpg"><br>
</h1>

* `💣 📱 💀`<br />
* `A Superfast SMS & Call bomber for Linux And Termux !`

## Disclaimer
*This tool is for educational purposes only !*
_Don't use this to take revenge_<br />
*I will not be responsible for any misuse*

## About
* `Unlimited Usage !`
* `Cross Platform`
* `Supports newest Android also`
* `No balance will be deducted to send SMS/calls`
* `Working Apis`
* `No missing SMS issues, all messages will be sent.`
* `Working with all Operators/Carriers`

## Tested On :
<ul>
  <li>Kali Linux</li>
  <li>Termux</li>
  <li>Ubuntu</li>
  <li>Parrot Sec OS</li>
  <li>Kali nethunter</li>
  <li>Alpine linux</li>
  
</ul>

## Termux Issue:
* `Termux App is no longer recieving updates on playstore`
* `due to recently introduced Google Play policy `
<br>

DON'T WORRY
* `We have a solution for that !`
<br>


You can download the latest termux app and install it

From here <a href="https://f-droid.org/repo/com.termux_117.apk">Link</a>

## Usage



#### For Termux

Update the packages
```bash
pkg up -y
```
Install some dependencies
```bash
pkg install git wget python3 -y
```
Clone the repository
```bash
git clone https://github.com/superxploiter/XLR8_BOMBER
```
Go to the Xlr8 directory
```bash
cd XLR8_BOMBER
```
Run the script
```bash
python xlr8.py
```



#### For Debian-based GNU/Linux distributions

Update the packages
```bash
apt-get update; apt-get upgrade -y
```
Install some dependencies
```bash
apt-get install git wget python3 -y
```
Clone the repository
```bash
git clone https://github.com/superxploiter/XLR8_BOMBER
```
Go to the Xlr8 directory
```bash
cd XLR8_BOMBER
```
Run the script
```bash
sudo python3 xlr8.py
```

## Anonymous Msg Passcode

You'll get that in the telegram channel !

## Version
* `3.1.8 CI aplha`

## Features
* `Sms,Call & Whatsapp Bombing`

* `Send anonymous msg`

## Note
* `This bomber only works in India !!`

## Licence
Apache 2.0 © Anubhav Kashyap


## Screenshots (Termux)

<br>
<p align="center">
<img width="48%" src="screenshots/IMG_20210531_101730.jpg"/>
<img width="48%" src="screenshots/IMG_20210530_164910.jpg"/>
</p>
<p align="centre">
<img width="48%" src="screenshots/IMG_20210530_165509.jpg"/>
<img width="48%" src="screenshots/IMG_20210530_165506.jpg"/>
</p>

## Contact Us
* `If you have any feedback or queries`
* `mail us at: anubhavkashyap@pm.me`

## Telegram Channel

* `All updates of Xlr8 will be posted here !`

<a href="https://t.me/xlr8bomber">
         <img src="https://smartiblogster.com/wp-content/uploads/2021/03/smartiblogster-iblogster-join-telegram-channel.png">
